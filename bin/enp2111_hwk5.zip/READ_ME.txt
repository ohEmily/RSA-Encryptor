****************************************************************
****** RSA Encryption/Decryption Assignment (12/04/2013) *******
****************************************************************
                             (COMS3134 Data Structures, Pasik) *
                                                Emily Pakulski *
                                          enp2111@columbia.edu *
****************************************************************

Hello!

This program should run as described in the assignment. So you
can use the commands in the assignment: 

java rsa/Makekeys bob
java rsa/Encode bob.public < message > code
java rsa/Encode bob.public < message | java rsa/Encode bob.private

The exponential algorithm computing b^n also runs in log(n) time,
as does the algorithm to compute the inverse of a number in 
mod(n).

Thanks for reading. I hope you had a good Thanksgiving break!
-Emily

